/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.stringpractice;

/**
 *
 * @author S555058
 */
public class StringPractice {

    public static void main(String[] args) {
        String str1="System",str2="Debug",str3="Cats";
       System.out.println(str1 +' '+ str2 +' '+ str3);
        int num=3379;
       str2 =str1+str2;
       System.out.println(str2);
        str3= str3+' '+num;
       System.out.println(str2 + ' '+ str3 );
      }
}
