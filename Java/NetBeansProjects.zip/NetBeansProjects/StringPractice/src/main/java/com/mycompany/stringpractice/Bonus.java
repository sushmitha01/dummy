/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stringpractice;

/**
 *
 * @author S555058
 */
import java.util.Scanner;
import java.util.Random;

public class Bonus {
    public static void main(String args[])
    {
    String str2;
    
    Scanner st= new Scanner(System.in);
   /*  System.out.println("Enter a String :" + str2); */
   
   /*** step 1 ***/
   
    str2=st.nextLine();
    System.out.println("Enter a String :" + str2);
    
    Random rand = new Random();
     /* int rand1= rand.nextInt(str2.length());
     System.out.println(rand1);  */
     System.out.println(str2.charAt(rand.nextInt(str2.length())));
     
     /** Step2 **/
      
     
    }
    
    
}
