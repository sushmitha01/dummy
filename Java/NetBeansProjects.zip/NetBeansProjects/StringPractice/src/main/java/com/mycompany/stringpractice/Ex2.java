/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stringpractice;

/**
 *
 * @author S555058
 */
public class Ex2 {
    public static void main(String args[])
    {
   /* Step1  */
    String data ="abcde";
    /*Scanner stdin=new Scanner(System.in);*/
       /*str3 =stdin.nextLine();*/ 
    int n=data.length();
    System.out.println(data);

    char data_1= data.charAt(0);
    char data_2=data.charAt(n/2);
    char data_3= data.charAt(n-1);
    
    System.out.println(data_1+"G"+data_2+"G"+data_3);
    
     String data1 ="Dancing";
    /*Scanner stdin=new Scanner(System.in);*/
       /*str3 =stdin.nextLine();*/ 
    int n1=data1.length();
    System.out.println(data1);

    char data_11= data1.charAt(0);
    char data_12=data1.charAt(n/2);
    char data_13= data1.charAt(n-1);
    
    System.out.println(data_11+"G"+data_12+"G"+data_13);
             
  /* Step2 */
   
    String st1="abcde";
      /*Scanner stdin=new Scanner(System.in);*/
       /*str3 =stdin.nextLine();*/ 
    
    int l = st1.length();
    /* System.out.println(l); */
    String result=st1.substring(1,l-2);
    System.out.println(result);
    
    String stm="Dancing";
      /*Scanner stdin=new Scanner(System.in);*/
       /*str3 =stdin.nextLine();*/ 
    
    int L = stm.length();
   /* System.out.println(L); */
    String result1=stm.substring(1,L-2);
    System.out.println(result1);
    
 /* Step 3*/
    String st ="abcde";
    
    int len = st.length();
    /* System.out.println(len); */
    String A=st.substring(0,(len/2)-1);
    String B=st.substring(((len/2)+2),len);
    B=B.toUpperCase();
    System.out.println(A+B);
    
    String st7 ="Dancing";
    
    int len_A = st7.length();
    /* System.out.println(len); */
    String C=st7.substring(0,(len_A/2)-1);
    String D=st7.substring(((len_A/2)+2),len_A);
    D=D.toUpperCase();
    System.out.println(C+D);
    
    String st8 ="ComputerScience";
    
    int len_B = st8.length();
    /* System.out.println(len); */
    String E=st8.substring(0,(len_B/2)-1);
    String F=st8.substring(((len_B/2)+2),len_B);
    F=F.toUpperCase();
    System.out.println(E+F);
    
   
  
            
    
    
    /*char str1=str3.charAt(l);
    char str2=str3.charAt(l-1);
      System.out.println(str1+str2); */
    
    }}

    
