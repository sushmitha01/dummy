/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.stringpractice;

/**
 *
 * @author S555058
 */
import java.util.Random;
public class EX3 {
    public static void main(String[]args)
    {   
     Random rand = new Random();
     int rand1= rand.nextInt(51);
     System.out.println(rand1);
   
     int rand2;
     rand2 = rand.nextInt(51);
     System.out.println(rand2);
     
     int rand3;
     rand3 = rand.nextInt(-500, -1);
     System.out.println(rand3);
     
 /*  step 3   */
      double A= rand.nextDouble(0,1);
      System.out.println(A);
      
      double B= rand.nextDouble(-5 , 5);
      System.out.println(B);
      
      double C= rand.nextDouble(1/7 , 5/7)h;
      System.out.println(C);
      
    /* Step 4 */
   
      
      
      
      
 
     */
     
     
     }        
    }
    


    
