/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author S555058
 */
public class proj {
    public static void main(String args[])
    {
   /* Step1  */
    String data ="abcdef";
    int n=data.length();

    char data1= data.charAt(0); 
    char data2=data.charAt(n/2);
    char data3= data.charAt(n);
    
    System.out.println(data1+"G"+data2+"G"+data3);
             
        
   
    String st1="abcdefghj";
      /*Scanner stdin=new Scanner(System.in);*/
       /*str3 =stdin.nextLine();*/ 
    
    int l = st1.length();
    System.out.println(l);
    String result=st1.substring(1,l-2);
    System.out.println(result);
    
 
    String st ="Somethinginteresting";
    
    int len = st.length();
    System.out.println(len);
    String A=st.substring(0,(len/2)-1);
    String B=st.substring((len/2)+2,len);
    B=B.toUpperCase();
    System.out.println(A+B);
    
            
    
    
    /*char str1=str3.charAt(l);
    char str2=str3.charAt(l-1);
      System.out.println(str1+str2); */
    
    }}
