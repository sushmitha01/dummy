
# SUSHMITHA 
###### Salar Jung Museum 

 It has a collection of **sculptures, paintings, carvings, textiles, manuscripts, ceramics, metallic artifacts, carpets, clocks, and furniture /** from Japan, China, Burma, Nepal, India, Persia, Egypt, Europe, and North America
 